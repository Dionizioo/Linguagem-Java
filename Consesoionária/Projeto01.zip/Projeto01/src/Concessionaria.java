import java.util.List;

// Classe Concessionaria
public class Concessionaria {
    private Armazenamento  armazenamento;

    // Construtor da classe Concessionaria
    public Concessionaria(Armazenamento armazenamento) {
        this.armazenamento = armazenamento;
    }

    // Método para adicionar um veículo ao armazenamento
    public void adcionarVeiculo(Veiculo veiculo){
        armazenamento.adicionarVeiculo(veiculo);
    }

    // Método para listar os veículos disponíveis
    public List<Veiculo> listarVeiculos(){
        return armazenamento.recuperarVeiculos();
    }
}
