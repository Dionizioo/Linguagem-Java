import java.util.ArrayList;
import java.util.List;

// Classe BancoDeDadosArmazenamento que implementa Armazenamento
 class BancoArmazenamento implements Armazenamento {
    private List<Veiculo> veiculos = new ArrayList<>();

    @Override
    public void adicionarVeiculo(Veiculo veiculo) {
        veiculos.add(veiculo);
    }

    @Override
    public List<Veiculo> recuperarVeiculos() {
        return veiculos;
    }
}
