import java.util.List;

public class Main {
    public static void main(String[] args) {

        Carro carro1 = new Carro("Camaro","Chevrolet", 2023 , 1000000.0 , 2);
        Carro carro2 = new Carro("Ferrari","Ferrari", 2015 , 10000.0 , 2);

        Motocicleta moto1 = new Motocicleta("Honda","Chevrolet",2016 , 50000.0,600 );
        Motocicleta moto2 = new Motocicleta("Kawasaki","Ninja 400",2023 , 9000.0,800 );

        Armazenamento armazenamento = new BancoArmazenamento();
        //Armazenamento armazenamento1 = new ArquiArmazenamento("src/veiculos.txt");

        Concessionaria concessionaria = new Concessionaria(armazenamento);

        concessionaria.adcionarVeiculo(carro1);
        concessionaria.adcionarVeiculo(carro2);
        concessionaria.adcionarVeiculo(moto1);
        concessionaria.adcionarVeiculo(moto2);

        List<Veiculo> veiculos = concessionaria.listarVeiculos();
        for (Veiculo veiculo : veiculos){
            System.out.println(veiculo.getMarca() + " " + veiculo.getModelo() + " (" + veiculo.getAno() + ") - R$ " + veiculo.getPreco());
        }
    }
}