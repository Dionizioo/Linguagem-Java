public class Veiculo {
    private String marca;
    private String modelo;
    private int ano;
    private double preco;

    //contrutores da classe veiculos
    public Veiculo( String marca, String modelo, int ano, double preco){
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
        this.preco = preco;
    }

    // Getters para obter informações do veiculo
    public String getMarca(){
        return marca;
    }
    public String getModelo(){
        return modelo;
    }
    public int getAno(){
        return ano;
    }
    public double getPreco(){
        return preco;
    }
}
